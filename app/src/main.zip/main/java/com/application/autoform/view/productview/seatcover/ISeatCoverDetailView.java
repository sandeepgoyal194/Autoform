package com.application.autoform.view.productview.seatcover;

import com.application.autoform.model.bean.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sandeep on 26/10/2016.
 */

public interface ISeatCoverDetailView {
    void setSeatCoverImages(ArrayList<Product> product);

}
