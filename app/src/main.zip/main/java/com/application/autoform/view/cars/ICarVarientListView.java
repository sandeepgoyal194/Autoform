package com.application.autoform.view.cars;

import com.application.autoform.model.bean.Car;

import java.util.List;

/**
 * Created by Sandeep on 06/11/2016.
 */

public interface ICarVarientListView {
    public void setCarVarientList(List<Car> cars);
}
