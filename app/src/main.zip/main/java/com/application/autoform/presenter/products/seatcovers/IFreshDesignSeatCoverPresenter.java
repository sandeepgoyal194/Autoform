package com.application.autoform.presenter.products.seatcovers;

/**
 * Created by sandeep.g9 on 10/20/2016.
 */

public interface IFreshDesignSeatCoverPresenter {
    void getFreshSeatCovers();

}
