package com.application.autoform.presenter.cars;

/**
 * Created by Sandeep on 06/11/2016.
 */

public interface ICarVarientListPresenter {
    void getCarVarients(String brand);
}
