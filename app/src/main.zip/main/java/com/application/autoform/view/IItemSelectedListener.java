package com.application.autoform.view;

/**
 * Created by madhurigupta on 23/01/17.
 */

public interface IItemSelectedListener {
    void onItemSelected(String title);
}
