package com.application.autoform.presenter.products.whyus;

/**
 * Created by Sandeep on 05/04/2017.
 */

public interface IWhyUsPresenter {
    public void onViewStarted();
    public void onViewStopped();
}
