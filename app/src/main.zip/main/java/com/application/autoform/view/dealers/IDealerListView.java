package com.application.autoform.view.dealers;

import com.application.autoform.model.bean.Dealer;

import java.util.List;

/**
 * Created by sandeep.g9 on 11/9/2016.
 */

public interface IDealerListView {
    public void setDealerList(List<Dealer> dealerList);
}
