package com.application.autoform.presenter.products.cart;

/**
 * Created by sandeep.g9 on 3/21/2017.
 */

public interface IUserSubmitDetailPresenter {
    public void onSubmitClick();
}
