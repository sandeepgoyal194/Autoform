package com.application.autoform.view.dashboard;

import com.application.autoform.model.bean.Accessories;

import java.util.ArrayList;

/**
 * Created by madhurigupta on 11/01/17.
 */

public interface IAccessoriesView {
    void setAccessoriesList(ArrayList<Accessories> accessories);
}
