package com.application.autoform.view.productview.seatcover;

import com.application.autoform.model.bean.Product;

import java.util.List;

/**
 * Created by sandeep.g9 on 10/20/2016.
 */

public interface IFreshDesignSeatCoverView {
    public void setFreshSeatCovers(List<Product> seatCovers);
}
