package com.application.autoform.view.productview.seatcover;

import com.application.autoform.model.bean.SubCategory;

/**
 * Created by Sandeep on 07/05/2017.
 */

public interface ISubCategoryView {
    public void setSubCategoryDetail(SubCategory subCategoryDetail);
}
