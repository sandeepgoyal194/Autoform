package com.application.autoform.model.bean;

/**
 * Created by sandeep.g9 on 3/22/2017.
 */

public class WishListProduct {
    String designName;
    String category;
    String subCategory;
    String Model;
    String modelVarient;
    String majorColor;
    String minorColor;
    String majorColorPath;
    String minorColorPath;
    String productDesginPath;

    public String getDesignName() {
        return designName;
    }

    public void setDesignName(String designName) {
        this.designName = designName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String model) {
        this.Model = model;
    }

    public String getModelVarient() {
        return modelVarient;
    }

    public void setModelVarient(String modelVarient) {
        this.modelVarient = modelVarient;
    }

    public String getMajorColor() {
        return majorColor;
    }

    public void setMajorColor(String majorColor) {
        this.majorColor = majorColor;
    }

    public String getMinorColor() {
        return minorColor;
    }

    public void setMinorColor(String minorColor) {
        this.minorColor = minorColor;
    }

    public String getMajorColorPath() {

        return majorColorPath;
    }

    public void setMajorColorPath(String majorColorPath) {
        this.majorColorPath = majorColorPath;
    }

    public String getMinorColorPath() {
        return minorColorPath;
    }

    public void setMinorColorPath(String minorColorPath) {
        this.minorColorPath = minorColorPath;
    }

    public String getProductDesginPath() {
        return productDesginPath;
    }

    public void setProductDesginPath(String productDesginPath) {
        this.productDesginPath = productDesginPath;
    }
}
