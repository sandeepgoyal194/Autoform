package com.application.autoform.view.cars;

import com.application.autoform.model.bean.CarBrand;

import java.util.List;

/**
 * Created by Sandeep on 03/11/2016.
 */

public interface ICarBrandListView {
    public void setCarBrandList(List<CarBrand> carBrandList);
}
