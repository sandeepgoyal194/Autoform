package com.application.autoform.presenter;

/**
 * Created by madhurigupta on 11/01/17.
 */

public interface IAccessoriesListPresenter {
    void getAccessoriesList();
}
