package com.application.autoform.view.productview.seatcover;

import com.application.autoform.model.bean.Color;

import java.util.List;

/**
 * Created by sandeep.g9 on 11/3/2016.
 */

public interface IColorListView {
    public void setColorList(List<Color> colorList);
}
