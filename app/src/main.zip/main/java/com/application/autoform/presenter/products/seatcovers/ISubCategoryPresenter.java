package com.application.autoform.presenter.products.seatcovers;

/**
 * Created by Sandeep on 07/05/2017.
 */

public interface ISubCategoryPresenter {
    public void onViewFocus();
    public void getSubCategory(String subCategory);
}
