package com.application.autoform.presenter.cars;

/**
 * Created by Sandeep on 03/11/2016.
 */

public interface ICarBrandPresenter {
    void getCarBrandList();
}
