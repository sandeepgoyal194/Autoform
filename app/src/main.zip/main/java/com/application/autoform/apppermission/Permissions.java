package com.application.autoform.apppermission;

import android.Manifest;

/**
 * Created by Sandeep on 21/01/2017.
 */

public class Permissions {
    public static final String PERMISSION_CALL_PHONE = Manifest.permission.CALL_PHONE;
}
